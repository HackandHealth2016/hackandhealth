#install.packages("openxlsx")

setwd("~/Desktop/Health")
# Importacio i neteja de dades
library(openxlsx)
data <- read.xlsx("HealthApp_Dades_HackandHealth.xlsx", sheet = "EPISODES")
genders<-c(1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1)
environments<- c(1,1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0)
data$GENDER<-rep(genders,rep(276,30))
data$ENVIRONMENT<-rep(environments,rep(276,30))
v<-rep(genders,each=276)
vec<-c(rep(0,15),rep(1,258),rep(0,3))
data$vec2<-rep(vec,30)
data<-(subset(data, vec2==1))
dat <- data[,1:(length(colnames(data))-1)]
dat$DAYnum <- rep(1:258,30)

# Creacio del model
library(caret)
library(ggplot2)
library(pls)

# Particio entre pacients d'entrenament i de test
set.seed(258)
sample(30,6)
part <- rep(c(0,0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0), each = 258)
dat$part <- part

datrain = subset(dat,part==0)[,1:(length(colnames(dat))-1)]
datest = subset(dat,part==1)[,1:(length(colnames(dat))-1)]
dat <- dat[,1:(length(colnames(dat))-1)]

# Model amb les variables triades
plsFitTime <- train(Y ~ Epi5 + Epi4 + Mea1 + Stu1 + Spo1 + Fam1 + Fri1 + Epi1 + Stu2 + Spo2 + 
                      Fam2 + Fri2 + Alo2 + Epi2 + Bad2 + Mea3 + Stu3 + Spo3 + Fam3 + 
                      Fri3 + Alo3 + Epi3 + Bad3 + ENVIRONMENT,
                    data = datrain,
                    method = "knn",
                    tuneLength = 10,
                    preProc = c("center", "scale"),
                    trControl = trainControl(method = "boot"))
colnames(datrain)
# Prediccio
pred <- predict(plsFitTime,datinput)
output <- round(pred*100,1)

# Modelitzacio de variables del model:
library(plm)
model<- plm(Y ~ Epi5 + Spo1 +  
              Epi1 + Stu2 + Spo2 + Fam2 + Fri2 + 
              Alo2 + Epi2 + Bad2 + Stu3 + Spo3 +Fri3 + Alo3 + 
              Bad3 +Stu4 + Spo4 + Fam4 + Fri4 + Epi4 + 
              GENDER + ENVIRONMENT ,
            data=dat, index = c("PATIENT", "DAYnum"))

summary(model)


reg1<-step(model, direction = "both")
reg1$coefficients

model<- lm(Y ~ Epi5 + Bad5 + Mea1 + Stu1 + Spo1 + Fam1 + 
             Fri1 + Alo1 + Epi1 + Bad1 + Mea2 + Stu2 + Spo2 + Fam2 + Fri2 + 
             Alo2 + Epi2 + Bad2 + Mea3 + Stu3 + Spo3 + Fam3 + Fri3 + Alo3 + 
             Epi3 + Bad3 +GENDER + ENVIRONMENT, data=dat)
summary(model)

reg<-step(model, direction = "both")




install.packages("openxlsx")
library(openxlsx)
data <- read.xlsx("HA.xlsx", sheet = "EPISODES")
genders<-c(1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1)
environments<- c(1,1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0)
data$GENDER<-rep(genders,rep(276,30))
data$ENVIRONMENT<-rep(environments,rep(276,30))
v<-rep(genders,each=276)
vec<-c(rep(0,15),rep(1,258),rep(0,3))
data$vec2<-rep(vec,30)

data<-(subset(data, vec2==1))
dim(data)
colnames(data)
dat<-data[,-c(1,2,3,4,5,6,7,37)]
dat[is.na(dat)] <- 0



#abs(cor(dat))>0.8    comprobacion no colinealidad

model<- lm(y~., data=dat)
summary(model)

reg1<-step(model, direction = "both")
reg1$coefficients

model<- lm(y~epi + bad + stud + spo + fam + fri + alo + env, data=dat)
summary(model)

reg2<-regsubsets(y~., data=dat)
summary(reg2)

data <- read.xlsx("HA.xlsx", sheet = "EPISODES")
data$DAY <- rep(seq(as.Date("2015/11/1"), as.Date("2016/1/31"), "days"),each = 3)
genders<-c(1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1)
environments<- c(1,1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0)
data$GENDER<-rep(genders,rep(276,30))
data$ENVIRONMENT<-rep(environments,rep(276,30))
data$HOUR <- rep(1:3,length(dat$HOUR)/3)


data <- read.xlsx("HA.xlsx", sheet = "EPISODES")
data$DAY <- seq(1:276)
genders<-c(1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1)
environments<- c(1,1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0)
data$GENDER<-rep(genders,rep(276,30))
data$ENVIRONMENT<-rep(environments,rep(276,30))

dim(data)
colnames(data)
dat<-data[,c(1:7,35)]
dat[is.na(dat)] <- 0
dat <- dat[,-c(3)]


mytable <- ftable(Activity = dat$ACTIVITY[which(dat$EMOTION!=0)],Emotion = dat$EMOTION[which(dat$EMOTION!=0)],Gender = dat$GENDER[which(dat$EMOTION!=0)]) # A will be rows, B will be columns 
mytable # print table 
mosaic(mytable,shade = T, legend = T)
library(graphics)
assocplot(mytable)
mosaicplot(~ Activity + Emotion, data = mytable,color = heat.colors(6),las = 1)

mytable <- table(Meal = dat$MEAL[which(dat$EMOTION!=0)],Emotion = dat$EMOTION[which(dat$EMOTION!=0)])
mytable # print table 
mosaicplot(~ Meal + Emotion, data = mytable,color = heat.colors(6),las = 1)

mytable <- table(Activity = dat$ACTIVITY[which(dat$EMOTION!=0)],Emotion = dat$EMOTION[which(dat$EMOTION!=0)]) # A will be rows, B will be columns 
mt <- as.data.frame(mytable)
mytable # print table 
pmytable <- prop.table(mytable)
pmytable
mosaic(mytable, shade=TRUE, legend=TRUE)
assoc(mytable, shade=TRUE)

p_activity <- prop.table(mytable,2)
p_activity
barplot(p_activity,col=2:6,legend=T)


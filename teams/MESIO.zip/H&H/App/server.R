library(shiny)
library(plyr)
library(reshape2)
library(ggplot2)



shinyServer(function(input, output) {
  
  data <- reactive ({
    library(openxlsx)
    data <- read.xlsx("HA.xlsx", sheet = "EPISODES")
    data$DAY <- seq(1:276)
    genders<-c(1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1)
    environments<- c(1,1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0)
    data$GENDER<-rep(genders,rep(276,30))
    data$ENVIRONMENT<-rep(environments,rep(276,30))
    
    dim(data)
    colnames(data)
    dat<-data[,c(1:7,35)]
    dat[is.na(dat)] <- 0
    data <- dat[,-c(3)]
    data
  })
  
  s <- reactive ({
    s <- subset(data(),data()$PATIENT == as.character(input$Pa))
    s
  })
  
   output$PlotDat <- renderPlot({
     mytable <- table(Activity = s()$ACTIVITY[which(s()$EMOTION!=0)],Emotion = s()$EMOTION[which(s()$EMOTION!=0)]) # A will be rows, B will be columns 
     mosaicplot(~ Activity + Emotion, data = mytable,color = c("blue4","dodgerblue4","dodgerblue3","dodgerblue2","dodgerblue1","deepskyblue"),las = 1,main = "")   
  })

   output$PlotDat2 <- renderPlot({
     mytable2 <- table(Meal = s()$MEAL[which(s()$EMOTION!=0)],Emotion = s()$EMOTION[which(s()$EMOTION!=0)]) # A will be rows, B will be columns 
     mosaicplot(~ Meal + Emotion, data = mytable2,color = c("blue4","dodgerblue4","dodgerblue3","dodgerblue2","dodgerblue1","deepskyblue"),las = 1,main = "")   
   })
   
   dat <- reactive ({
     library(openxlsx)
     data <- read.xlsx("HealthModel.xlsx", sheet = "EPISODES")
     genders<-c(1,1,1,1,0,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0,1,1,1,1,1)
     environments<- c(1,1,1,1,1,0,1,1,1,1,0,0,1,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0)
     data$GENDER<-rep(genders,rep(276,30))
     data$ENVIRONMENT<-rep(environments,rep(276,30))
     v<-rep(genders,each=276)
     vec<-c(rep(0,15),rep(1,258),rep(0,3))
     data$vec2<-rep(vec,30)
     data<-(subset(data, vec2==1))
     dat <- data[,1:(length(colnames(data))-1)]
     dat$DAYnum <- rep(1:258,30)
     dat
   })
   
   model <- reactive ({
   # Creacio del model
   library(caret)
   library(ggplot2)
   
   # Particio entre pacients d'entrenament i de test
   set.seed(258)
   sample(30,6)
   part <- rep(c(0,0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0), each = 258)
   dat <- dat()
   dat$part <- part
   
   datrain = subset(dat,part==0)[,1:(length(colnames(dat))-1)]
   datest = subset(dat,part==1)[,1:(length(colnames(dat))-1)]
   dat <- dat[,1:(length(colnames(dat))-1)]
   
   # Model amb les variables triades
   model <- train(Y ~ Epi5 + Epi4 + Mea1 + Stu1 + Spo1 + Fam1 + Fri1 + Epi1 + Stu2 + Spo2 + 
                         Fam2 + Fri2 + Alo2 + Epi2 + Bad2 + Mea3 + Stu3 + Spo3 + Fam3 + 
                         Fri3 + Alo3 + Epi3 + Bad3 + ENVIRONMENT,
                       data = datrain,
                       method = "knn",
                       tuneLength = 10,
                       preProc = c("center", "scale"),
                       trControl = trainControl(method = "boot"))
   model
   })
   
   datinput <- reactive({
     p <- as.character(input$Pa)
     d <- input$date
     df <- data.frame(seq(1,258,3),seq.Date(as.Date("2015-11-06"),as.Date("2016-01-30"),"days"))
     dia <- df[which(d==df[,2]),1]
     datinput <- subset(dat(),dat()$PATIENT == p & dat()$DAYnum == dia)
     datinput
   })
  
   output$pred <- renderText({
     pred <- predict(model(),datinput())
     output <- round(pred*100,1)
     output<-as.character(output)
     paste("The probability that the patient", as.character(input$p), "has an episode today is:", "<font size=7><b>", output,"</b></font>", "%.")
   })

   
})
